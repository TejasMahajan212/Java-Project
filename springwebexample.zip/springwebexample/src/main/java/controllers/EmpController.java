package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dbconnect.DbConnect;
import model.Admin;
import model.Emp;
import model.Project;
import model.Task;
import services.Adminbean;
import services.EmpBean;
import services.Projectbean;

@Controller
public class EmpController {
	@RequestMapping("emp")
	public ModelAndView empview(HttpSession session) {
		if (session.getAttribute("sessuid") == null) {
			return new ModelAndView("redirect:admin.do");
		}
		ModelAndView obj = new ModelAndView("empview", "command", new EmpBean());
		obj.addObject("res1", getEmpData());
		obj.addObject("btntitle", "Insert");
		return obj;

	}

	@RequestMapping("empfind")
	public ModelAndView empfindInfo(HttpServletRequest request) {
		Emp emp = findEmpData(Integer.parseInt(request.getParameter("q").toString()));
		ModelAndView obj = new ModelAndView("empview", "command", emp);
		obj.addObject("res1", getEmpData());
		obj.addObject("btntitle", "Update");
		return obj;
	}

	@RequestMapping("empinsert")
	public ModelAndView empinsert(@ModelAttribute("springmvc6") EmpBean s, HttpServletRequest request) {
		String msg = "";
		if (request.getParameter("btnsubmit").equals("Insert")) {
			insertEmpData(s);
			msg = "data inserted successfully";
		} else {
			updateEmpData(s);
			msg = "data updated successfully";
		}

		ModelAndView obj1 = new ModelAndView("empview", "command", new EmpBean());
		obj1.addObject("res", msg);
		obj1.addObject("res1", getEmpData());
		obj1.addObject("btntitle", "Insert");

		return obj1;
	}

	@RequestMapping("empupdate")
	public ModelAndView empUpdate(@ModelAttribute("springmvc6") EmpBean s) {
		updateEmpData(s);
		ModelAndView obj1 = new ModelAndView("empview", "command", new EmpBean());
		obj1.addObject("res", "data inserted successfully");
		obj1.addObject("res1", getEmpData());
		obj1.addObject("btntitle", "Insert");
		return obj1;

	}

	@RequestMapping("empdelete")
	public ModelAndView empDelete(HttpServletRequest request) {
		deleteEmpData(Integer.parseInt(request.getParameter("q").toString()));
		ModelAndView obj1 = new ModelAndView("empview", "command", new EmpBean());
		obj1.addObject("res", "data deleted successfully");
		obj1.addObject("res1", getEmpData());
		obj1.addObject("btntitle", "Insert");
		return obj1;
	}

	@RequestMapping("project")
	public ModelAndView enterproject() {
		return new ModelAndView("projectassign", "command", new Projectbean());
	}

	@RequestMapping("insertproject")
	public ModelAndView insertProject(@ModelAttribute("springmvc6") Projectbean s) {
		projectAdd(s);
		ModelAndView obj = new ModelAndView("projectassign", "command", new Projectbean());
		obj.addObject("projectkey", "Project data Inserted");
		obj.addObject("clientkey", new ClientController().getClientData());
		return obj;
	}

	public void insertEmpData(EmpBean s) {
		/*
		 * Configuration cfg = new Configuration(); cfg.configure("hibernate.cfg.xml");
		 * SessionFactory sf = cfg.buildSessionFactory(); Session sess =
		 * sf.openSession(); Transaction tx= sess.beginTransaction();
		 */
		DbConnect.connect();
		Emp obj = new Emp();
		obj.setEmpid(s.getEmpid());
		obj.setEmpname(s.getEmpname());
		obj.setJob(s.getJob());
		obj.setSalary(s.getSalary());
		obj.setUsername(s.getUsername());
		obj.setPassword(s.getPassword());
		DbConnect.insert(obj);
		DbConnect.closeConn();
	}

	public void updateEmpData(EmpBean s) {
		DbConnect.connect();
		Emp obj = new Emp();
		obj.setEmpid(s.getEmpid());
		obj.setEmpname(s.getEmpname());
		obj.setJob(s.getJob());
		obj.setSalary(s.getSalary());
		obj.setUsername(s.getUsername());
		obj.setPassword(s.getPassword());
		DbConnect.update(obj);
		DbConnect.closeConn();

	}

	public List getEmpData() {
		DbConnect.connect();
		Query q = DbConnect.select("from Emp s");
		List lst = q.list();
		return lst;
	}

	public Emp findEmpData(int id) {
		DbConnect.connect();
		Object o = DbConnect.findOperation(Emp.class, id);
		Emp e = (Emp) o;
		return e;
	}

	public void deleteEmpData(int empId) {
		DbConnect.connect();
		Emp emp = (Emp) DbConnect.findOperation(Emp.class, empId);
		if (emp != null) {
			DbConnect.delete(emp);

		}
		DbConnect.closeConn();
	}

	public void projectAdd(Projectbean p) {
		DbConnect.connect();
		Project project = new Project();
		project.setProjectname(p.getProjectname());
		project.setProjectdesc(p.getProjectdesc());
		project.setDuedate(p.getDuedate());
		project.setClientid(p.getClientid());
		DbConnect.insert(project);
		DbConnect.closeConn();
	}
}

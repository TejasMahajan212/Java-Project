package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class HelloController {
	
	  @RequestMapping("add") 
	  public ModelAndView display() 
	  { 
	 return new ModelAndView("addition"); 
		  }
	 
		@RequestMapping("add_page")
		 public ModelAndView show(HttpServletRequest request,HttpServletResponse response)
		 {
			int a = Integer.parseInt(request.getParameter("txt1"));
			int b = Integer.parseInt(request.getParameter("txt2"));
			int c  = a+b;
			return new ModelAndView("addition","add1",+c);
		 }
	
}

package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Emp;
import model.Task;
import services.EmpBean;
import services.Taskbean;

@Controller
public class TaskController {
      @RequestMapping("addtask")
	 public ModelAndView addTask(HttpSession session) {
		 if(session.getAttribute("sessuid")==null)
		 {
			 return new ModelAndView("redirect:admin.do");
		 }
		 ModelAndView mobj = new ModelAndView("taskadd","command",new Taskbean());
		 mobj.addObject("empdata", new EmpController().getEmpData());
		 mobj.addObject("taskdata",viewTaskData());
		 mobj.addObject("btntitle","Insert");
		 return mobj;
      }
      
      @RequestMapping("inserttask")
	  public ModelAndView insertTask(@ModelAttribute("springmvc6")Taskbean s,HttpServletRequest request){
    	  String msg="";
  		if(request.getParameter("btnsubmit").equals("Insert"))
  		{
  		insertTaskData(s);
  		msg="data inserted successfully";
  		}
  		else
  		{
  		updateTaskData(s);
  		msg="data updated successfully";
  		}
    	  
	    	ModelAndView obj= new ModelAndView("taskadd","command",new Taskbean());
	       
	        obj.addObject("res",msg);
	        obj.addObject("empdata",new EmpController().getEmpData());
	        obj.addObject("taskdata",viewTaskData());
	        obj.addObject("btntitle","Insert");
	    	return obj;
	    }	
      
      @RequestMapping("taskupdate")
      public ModelAndView taskUpdate(@ModelAttribute("springmvc6")Taskbean s ){
  		updateTaskData(s);
  		ModelAndView obj1= new ModelAndView("taskadd","command",new Taskbean());
  		obj1.addObject("empdata",new EmpController().getEmpData());
  		obj1.addObject("res","data inserted successfully");
  		obj1.addObject("taskdata",viewTaskData());
  		obj1.addObject("btntitle","Insert");
  	
  		return obj1;
      }
      
      @RequestMapping("taskview")
	  public ModelAndView viewTask(@ModelAttribute("springmvc6")Taskbean s){
    	  insertTaskData(s);
	    	ModelAndView obj= new ModelAndView("taskadd","command",new Taskbean());
	          
	        obj.addObject("empdata",new EmpController().getEmpData());
	        
	    	return obj;
	    }	
      @RequestMapping("taskfind")
      public ModelAndView taskfindInfo(HttpServletRequest request){
  	   Task task =findTaskData((Integer.parseInt(request.getParameter("q").toString())));
  	    ModelAndView obj= new ModelAndView("taskadd","command",task);
     	 obj.addObject("empdata",new EmpController().getEmpData());
         obj.addObject("taskdata",viewTaskData());
         obj.addObject("btntitle","Update");
          return obj;
        }	
      @RequestMapping("taskdelete")
      public ModelAndView taskDelete(HttpServletRequest request) {
     	deleteTaskData(Integer.parseInt(request.getParameter("q").toString()));
     	 ModelAndView obj1 = new ModelAndView("taskadd","command",new Taskbean());
     	  obj1.addObject("empdata",new EmpController().getEmpData());
     	  obj1.addObject("res","data deleted successfully");
  		  obj1.addObject("taskdata",viewTaskData());
  		  obj1.addObject("btntitle","Insert");
  		  return obj1;
      }
      
      public void insertTaskData(Taskbean s)
  	{
  		Configuration cfg = new Configuration();
  	    cfg.configure("hibernate.cfg.xml");
  	    SessionFactory sf = cfg.buildSessionFactory();
  	    Session sess = sf.openSession();
  	  
  	    Transaction tx= sess.beginTransaction();
  	    Task obj = new Task();
  	    obj.setTaskid(s.getTaskid());
	    obj.setTasktitle(s.getTasktitle());
	    obj.setTaskdesc(s.getTaskdesc());
	    obj.setEmpid(s.getEmpid());
  	    sess.save(obj);
  	    tx.commit();
  	    sess.close();
  	}
      public List viewTaskData()
  	  {
  		Configuration cfg = new Configuration();
  	    cfg.configure("hibernate.cfg.xml");
  	    SessionFactory sf = cfg.buildSessionFactory();
  	    Session sess = sf.openSession();
  	    return sess.createQuery("from Task c").list();
  	    
  	  }
      public Task findTaskData(int id)
      {
      	 Configuration cfg = new Configuration();
          cfg.configure("hibernate.cfg.xml");
          SessionFactory sf = cfg.buildSessionFactory();
          Session sess = sf.openSession();
          Object o = sess.get(Task.class, id);
          Task t = (Task) o;
          return t;
      }
         
      public void deleteTaskData(int taskId) {
    	  Configuration cfg = new Configuration();
          cfg.configure("hibernate.cfg.xml");
          SessionFactory sf = cfg.buildSessionFactory();
          Session sess = sf.openSession();
          Transaction tx = sess.beginTransaction();
      Task task= (Task) sess.get(Task.class,taskId);
          if(task!=null) {
           sess.delete(task);
           tx.commit();
          }
          sess.close();
      }
      
      public void updateTaskData(Taskbean s){
      	Configuration cfg = new Configuration();
          cfg.configure("hibernate.cfg.xml");
          SessionFactory sf = cfg.buildSessionFactory();
          Session sess = sf.openSession();
          Transaction tx= sess.beginTransaction();
          Task obj = new Task();
          obj.setTaskid(s.getTaskid());
  	    obj.setTasktitle(s.getTasktitle());
  	    obj.setTaskdesc(s.getTaskdesc());
  	    obj.setEmpid(s.getEmpid());
          sess.update(obj);
          tx.commit();
          sess.close();

       }
       
      
     }
	
	

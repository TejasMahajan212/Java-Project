package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class Marksheet {

	@RequestMapping("display")
	public ModelAndView display() {
		
		
		return new ModelAndView("marksheet");
	}
	
	@RequestMapping("marksheet")
	public ModelAndView mark(HttpServletRequest req ,HttpServletResponse res) {
		
		int physic = Integer.parseInt(req.getParameter("physic"));
		int chemistry = Integer.parseInt(req.getParameter("chemistry"));
		int math = Integer.parseInt(req.getParameter("math"));
		int english = Integer.parseInt(req.getParameter("english"));
		int hindi = Integer.parseInt(req.getParameter("hindi"));
		
		int percentage = (physic+chemistry+math+english+hindi)/5;
		
		ModelAndView mv = new ModelAndView("marksheet","key",percentage);
		
//		mv.addObject("key1","Physics number is: "+physic);
//		mv.addObject("key2","Chemistry number is: "+chemistry);
//		mv.addObject("key3","Math number is: "+math);
//		mv.addObject("key4","English number is: "+english);
//		mv.addObject("key5","Hindi number is: "+hindi);
		
		return mv;
	}
}

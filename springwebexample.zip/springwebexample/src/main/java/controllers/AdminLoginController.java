package controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dbconnect.DbConnect;
import model.Admin;
import services.Adminbean;

@Controller
public class AdminLoginController {
	// login controller
	@RequestMapping("homepage")
	public ModelAndView homepage() {
		return new ModelAndView("home", "command", new Adminbean());
	}

	@RequestMapping("admin")
	public ModelAndView login() {
		return new ModelAndView("login", "command", new Adminbean());
	}

	@RequestMapping("logincode")
	public ModelAndView logincode(@ModelAttribute("springmvc6") Adminbean obj, HttpSession session) {
		if (loginData(obj.getUname(), obj.getUpass())) {
			session.setAttribute("sessuid", obj.getUname());
			return new ModelAndView("redirect:emp.do");
		} else {
			return new ModelAndView("login", "command", new Adminbean()).addObject("key",
					"Invalid userid and password");
		}
	}

	@RequestMapping("logout")
	public ModelAndView logout(HttpSession session) {
		session.removeAttribute("sessuid");
		return new ModelAndView("redirect:admin.do");
	}
	  public boolean loginData(String username, String password) {
		DbConnect.connect();
		Admin admin = new Admin();
		admin.setUsername(username);
		admin.setPassword(password);
		Query q = DbConnect.select("from Admin a where a.username=:u and a.password=:b");
		q.setString("u", admin.getUsername());
		q.setString("b", admin.getPassword());
		List lst = q.list();
		if (lst.size() > 0) {
			return true;
		} else {
			return false;
		}

	}

}

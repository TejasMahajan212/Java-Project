package controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dbconnect.DbConnect;
import model.Client;
import services.EmpBean;

@Controller
public class ClientController {
	@RequestMapping("client")
	public ModelAndView client() {
		return new ModelAndView("clientlogin", "command", new Client());
	}

	@RequestMapping("clientcode")
	public ModelAndView clientcode(@ModelAttribute("springmvc6") Client obj, HttpSession session) {
		if (loginData(obj.getCname(), obj.getCpass())) {
			// session.setAttribute("sessuid",obj.getCname());
			// return new ModelAndView("clientdesk","res",getEmpData());
			ModelAndView obj1 = new ModelAndView("clientdesk", "command", new Client());
			obj1.addObject("res", getEmpData());
			obj1.addObject("getclient", getClientData());
			return obj1;

		} else {
			return new ModelAndView("clientview", "command", new Client()).addObject("key",
					"Invalid userid and password");
		}
	}

	public boolean loginData(String cname, String cpass) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session sess = sf.openSession();
		Client client = new Client();
		client.setCname(cname);
		client.setCpass(cpass);
		Query q = sess.createQuery("from Client a where a.cname=:u and a.cpass=:b");
		q.setString("u", client.getCname());
		q.setString("b", client.getCpass());
		List lst = q.list();
		if (lst.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public List getEmpData() {
		DbConnect.connect();
		Query q = DbConnect.select("from Emp s");
		List lst = q.list();
		return lst;
	}

	public List getClientData() {
		DbConnect.connect();
		Query query = DbConnect.select("from Client c");
		List clist = query.list();
		return clist;
	}
}

package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RamController {
	 @RequestMapping("hello") 
	  public ModelAndView display() 
	  { 
	    return new ModelAndView("hello"); 
		  }
}


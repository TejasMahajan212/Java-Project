package controllers;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Emp;
import services.Adminbean;
import services.EmpBean;

@Controller
public class UserLoginCont {
	@RequestMapping("user")
	public ModelAndView login() {
		return new ModelAndView("userlogin", "command", new EmpBean());
	}

	@RequestMapping("emplogincode")
	public ModelAndView logincode(@ModelAttribute("springmvc6") EmpBean obj, HttpSession session) {
		if (loginData(obj.getUsername(), obj.getPassword())) {
			session.setAttribute("sesseid", findEmpid(obj.getUsername()));
			return new ModelAndView("userview", "assigndata", findTaskData(findEmpid(obj.getUsername())));
		} else {
			return new ModelAndView("userlogin", "command", new EmpBean()).addObject("key",
					"Invalid Username and Password");
		}
	}

	@RequestMapping("emplogout")
	public ModelAndView logout(HttpSession session) {
		session.removeAttribute("sesseid");
		return new ModelAndView("redirect:user.do");
	}

	public boolean loginData(String username, String password) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session sess = sf.openSession();
		Emp e = new Emp();
		e.setUsername(username);
		e.setPassword(password);
		Query q = sess.createQuery("from Emp em where em.username=:u and em.password=:b");
		q.setString("u", e.getUsername());
		q.setString("b", e.getPassword());
		List lst = q.list();
		if (lst.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public List findTaskData(int id) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session sess = sf.openSession();
		Query q = sess.createQuery("from Task t where t.empid=:a");
		q.setInteger("a", id);
		return q.list();
	}

	public int findEmpid(String username) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session sess = sf.openSession();
		Query q = sess.createQuery("from Emp e where e.username=:a");
		q.setString("a", username);
		List lst = q.list();
		Iterator it = lst.iterator();
		int empid = 0;
		while (it.hasNext()) {
			Emp emp = (Emp) it.next();
			empid = emp.getEmpid();
		}
		return empid;
	}
}

package dbconnect;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DbConnect {
     static  Configuration cfg;
     static SessionFactory sf;
     static Session session; 
     static Transaction tx;
	public static void connect() {
	  cfg = new Configuration();
	  cfg.configure("hibernate.cfg.xml");
	    sf = cfg.buildSessionFactory();
	  session =sf.openSession();
	}
	public static void insert(Object obj) {
		tx = session.beginTransaction();
		session.save(obj);
		tx.commit();
	}
	public static void update(Object obj) {
		tx = session.beginTransaction();
		session.update(obj);
		tx.commit();
	}
	public static void delete(Object obj) {
		tx = session.beginTransaction();
		session.delete(obj);
		tx.commit();
	}
	public static Query select(String query) {
		Query q = session.createQuery(query);
		return q;
	}
	public static Object findOperation(Class c,Integer id) {
		Object o = session.get(c, id);
		return o;
		
	}
	public static void closeConn() {
		session.close();
	}
}

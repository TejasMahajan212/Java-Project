package services;

public class Taskbean {
   private int taskid;
   private String tasktitle;
   private String taskdesc;
   private int empid;
public int getTaskid() {
	return taskid;
}
public void setTaskid(int taskid) {
	this.taskid = taskid;
}
public String getTasktitle() {
	return tasktitle;
}
public void setTasktitle(String tasktitle) {
	this.tasktitle = tasktitle;
}
public String getTaskdesc() {
	return taskdesc;
}
public void setTaskdesc(String taskdesc) {
	this.taskdesc = taskdesc;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
}

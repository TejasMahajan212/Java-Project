package services;

public class Projectbean {
   private int projectid;
   private String projectname;
   private String projectdesc;
   private String duedate;
   private int clientid;
public int getProjectid() {
	return projectid;
}
public void setProjectid(int projectid) {
	this.projectid = projectid;
}
public String getProjectname() {
	return projectname;
}
public void setProjectname(String projectname) {
	this.projectname = projectname;
}
public String getProjectdesc() {
	return projectdesc;
}
public void setProjectdesc(String projectdesc) {
	this.projectdesc = projectdesc;
}
public String getDuedate() {
	return duedate;
}
public void setDuedate(String duedate) {
	this.duedate = duedate;
}
public int getClientid() {
	return clientid;
}
public void setClientid(int clientid) {
	this.clientid = clientid;
}
}
